﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class admin_panel_Default : System.Web.UI.Page
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            MySqlCommand Cmd = new MySqlCommand("select * from admin_login_table where flduser='" + txtUserName.Text.Trim() + "' AND fldpwd='" + txtPwd.Text.Trim() + "'", Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                Session["admin-login"] = 1;
                Response.Redirect("home.aspx");
            }
            else
            {
                lblMsg.Text = "Invalid User Credentials !!";
            }
            Rdr.Close();
        }
    }
}
