﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;

public partial class admin_panel_BannerImages : System.Web.UI.Page
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin-login"] == null)
        {
            Response.Redirect("Default.aspx");
        }
        if (!IsPostBack)
        {
            Bind_Grid();
        }
    }

    private void Bind_Grid()
    {
        DataTable Dt = clsCommon.ExecuteSql("select * from banner_images_table order by id");
        GrdImages.DataSource = Dt;
        GrdImages.DataBind();
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        Button btnUpd = (Button)sender;
        string CommArg = btnUpd.CommandArgument.ToString();
        GridViewRow GrvR = (GridViewRow)btnUpd.NamingContainer;
        FileUpload flUpl =(FileUpload)GrdImages.Rows[GrvR.RowIndex].FindControl("FileUpload1");

        string strFileName = DateTime.Now.ToString("MM-dd-yyyy_HHmmss");
        string strFileType = System.IO.Path.GetExtension(flUpl.FileName).ToString().ToLower();

        //Save images into Images folder
        flUpl.SaveAs(Server.MapPath("~/banner-images/" + strFileName + strFileType));

        MySqlConnection Cn = new MySqlConnection(ConnStr.ToString());
        try
        {
            Cn.Open();
            //string sStrComm="Insert into gallery_table(img_desc,img_path) values(@ImageName,@ImagePath)";
            string sStrComm = "update banner_images_table set img_path=@ImagePath where id=" + CommArg + ""; 
            MySqlCommand cmd = new MySqlCommand(sStrComm, Cn);
            //cmd.Parameters.AddWithValue("@ImageName", txtDescrip.Text);
            cmd.Parameters.AddWithValue("@ImagePath", strFileName + strFileType);

            cmd.ExecuteNonQuery();
            Bind_Grid();

        }
        finally
        {
            Cn.Close();
        }
    }
}