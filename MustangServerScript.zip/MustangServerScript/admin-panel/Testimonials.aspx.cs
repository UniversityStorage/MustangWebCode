﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class admin_panel_Testimonials : System.Web.UI.Page
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin-login"] == null)
        {
            Response.Redirect("Default.aspx");
        }
        if (!IsPostBack)
        {
            Bind_Grid();
        }
    }

    private void Bind_Grid()
    {
        DataTable Dt = clsCommon.ExecuteSql("select * from testimonial_table order by id");
        GrdCustomers.DataSource = Dt;
        GrdCustomers.DataBind();
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {
        string strFileName = DateTime.Now.ToString("MM-dd-yyyy_HHmmss");
        string strFileType = System.IO.Path.GetExtension(FileUpload1.FileName).ToString().ToLower();

        //Save images into Images folder
        FileUpload1.SaveAs(Server.MapPath("~/testimonial-images/" + strFileName + strFileType));
        MySqlConnection Cn = new MySqlConnection(ConnStr.ToString());
        try
        {
            Cn.Open();
            string sStrComm = "Insert into testimonial_table(content_header,fldname,content_detail,img_path,is_selected) values(@cHeader,@Name,@cDetail,@ImagePath,0)";
            MySqlCommand cmd = new MySqlCommand(sStrComm, Cn);
            cmd.Parameters.AddWithValue("@cHeader", txtHeaderContent.Text.Trim());
            cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
            cmd.Parameters.AddWithValue("@cDetail", txtDetail.Text.Trim());
            cmd.Parameters.AddWithValue("@ImagePath", strFileName + strFileType);

            cmd.ExecuteNonQuery();
            Bind_Grid();

        }
        finally
        {
            Cn.Close();
            Cn.Dispose();
        }
        
    }

    protected void chkSelect_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chkSel = (CheckBox)sender;
        string strComm = chkSel.ToolTip.ToString();
        int intSelected = 0;
        if (chkSel.Checked == true)
        {
            intSelected = 1;
        }
        else
        {
            intSelected = 0;
        }
        MySqlConnection Cn = new MySqlConnection(ConnStr.ToString());
        try
        {
            Cn.Open();
            string sStrComm = "update testimonial_table set is_selected=" + intSelected + " where id=" + strComm + "";
            MySqlCommand cmd = new MySqlCommand(sStrComm, Cn);
            cmd.ExecuteNonQuery();
            Bind_Grid();
        }
        finally
        {
            Cn.Close();
            Cn.Dispose();
        }
    }

    protected void GrdCustomers_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox chkBx = (CheckBox)e.Row.FindControl("chkSelect");
            MySqlConnection Cn = new MySqlConnection(ConnStr.ToString());
            Cn.Open();
            string sStrComm = "select is_selected from testimonial_table where id=" + e.Row.Cells[0].Text + "";
            MySqlCommand cmd = new MySqlCommand(sStrComm, Cn);
            MySqlDataReader Rdr = cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                if ((int)Rdr[0] == 1)
                {
                    chkBx.Checked = true;
                }
                else
                {
                    chkBx.Checked = false;
                }
            }
            Rdr.Close();
            Rdr.Dispose();
            Cn.Close();
            Cn.Dispose();
        }
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            
                Cn.Open();
                Button BtnDel = (Button)sender; 
                string sStrComm = "delete from testimonial_table where id=" + BtnDel.CommandArgument.ToString()  + "";
                MySqlCommand cmd = new MySqlCommand(sStrComm, Cn);
                cmd.ExecuteNonQuery();
                Bind_Grid();
        }
    }
}
