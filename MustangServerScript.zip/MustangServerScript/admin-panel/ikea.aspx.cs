﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class admin_panel_ikea : System.Web.UI.Page
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin-login"] == null)
        {
            Response.Redirect("Default.aspx");
        }
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {

            Cn.Open();
            Button BtnDel = (Button)sender;
            string sStrComm = "delete from ikea_order_table where order_id=" + BtnDel.CommandArgument.ToString() + "";
            MySqlCommand cmd = new MySqlCommand(sStrComm, Cn);
            cmd.ExecuteNonQuery();
            Bind_Grid();
        }
    }

    private void Bind_Grid()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            DataTable Dt = clsCommon.ExecuteSql("select * from ikea_order_table where fldDate>='" + txtFrom.Text + "' And fldDate<='" + txtTo.Text + "' And is_payment_confirm=1");
            GridView1.DataSource = Dt;
            GridView1.DataBind();
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Bind_Grid();
    }
    
}
