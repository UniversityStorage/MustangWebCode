﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

/// <summary>
/// Summary description for Class1
/// </summary>
public class clsCommon
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    public clsCommon()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static DataTable ExecuteSql(string strSql)
    {
        MySqlConnection Cn = new MySqlConnection(ConnStr.ToString());       
        Cn.Open();
        MySqlDataAdapter sqlAdp = new MySqlDataAdapter(strSql, Cn);
        DataTable Dt=new DataTable();
        sqlAdp.Fill(Dt);
        Cn.Close();
        Cn.Dispose();
        sqlAdp.Dispose();
        return Dt;
    }
}