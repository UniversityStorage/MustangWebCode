﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class StorageCheckout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnCompleteOrder_Click(object sender, EventArgs e)
    {
        TextBox varTxtFirstName = (TextBox)this.BasicInfo.FindControl("txtFirstName");
        TextBox varTxtLastName = (TextBox)this.BasicInfo.FindControl("txtLastName");
        TextBox varTxtPhArea = (TextBox)this.BasicInfo.FindControl("txtPhAreaCode");
        TextBox varTxtPhNo = (TextBox)this.BasicInfo.FindControl("txtPhNo");
        TextBox varTxtAltArea = (TextBox)this.BasicInfo.FindControl("txtAltAreaCode");
        TextBox varTxtAltPhNo = (TextBox)this.BasicInfo.FindControl("txtAltPhNo");
        TextBox varTxtSchoolEmail = (TextBox)this.BasicInfo.FindControl("txtScEmail");
        TextBox varTxtParentEmail = (TextBox)this.BasicInfo.FindControl("txtParentEmail");

        if (varTxtFirstName.Text == "" || varTxtFirstName.Text == "First Name")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtLastName.Text == "" || varTxtLastName.Text == "Last Name")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtPhArea.Text == "" || varTxtPhArea.Text == "Area Code")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtPhNo.Text == "" || varTxtPhNo.Text == "Phone Number")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtAltArea.Text == "" || varTxtAltArea.Text == "Area Code")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtAltPhNo.Text == "" || varTxtAltPhNo.Text == "Phone Number")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtSchoolEmail.Text == "" || varTxtSchoolEmail.Text == "ex-myname@example.com")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtParentEmail.Text == "" || varTxtParentEmail.Text == "ex-myname@example.com")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        //------------------------------Delivery---------------- 
        TextBox varTxtDelDate = (TextBox)this.DelivInfo.FindControl("txtDate");
        DropDownList  varTxtDelTime = (DropDownList)this.DelivInfo.FindControl("dd_del_time");
        if (varTxtDelDate.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }

        if (varTxtDelTime.Text == "" || varTxtDelTime.Text == "--Select--")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        //----------------------- PICKUP -----------------------------------
          
        //-------------------------VALIDATION BILLING------------------------
        TextBox varTxtCardName = (TextBox)this.BillingInfo.FindControl("txtCardName");
        TextBox varTxtBillAdd = (TextBox)this.BillingInfo.FindControl("txtBillingAddress");
        TextBox varTxtZIP = (TextBox)this.BillingInfo.FindControl("txtZip");
        TextBox varTxtCardNo = (TextBox)this.BillingInfo.FindControl("txtCardNo");
        TextBox varTxtCSV = (TextBox)this.BillingInfo.FindControl("txtCardCode");
        DropDownList  varTxtExpMonth = (DropDownList)this.BillingInfo.FindControl("txtMonth");
        DropDownList  varTxtExpYear = (DropDownList)this.BillingInfo.FindControl("txtYear");
        if (varTxtCardName.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtBillAdd.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtZIP.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtCardNo.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtCSV.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtExpMonth.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtExpYear.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }

        foreach (TextBox txtBx in this.BasicInfo.Controls.OfType<TextBox>())
        {
            if (txtBx.Text == string.Empty)
            {
                return;
                break;
            }
        }
        string strTotal = Request.QueryString["tot"].ToString();
        Response.Redirect("Payment.aspx?Total=" + strTotal + "&ordertype=storage");
    }
}
