﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;
using System.Net.Mail;
using System.Net;
using System.Text.RegularExpressions;

public partial class _signup : System.Web.UI.Page 
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSignup_Click(object sender, EventArgs e)
    {
        if (Check_Already_Exist() == true)
        {
            lblSignupMsg.Text = "Email ID Already Exist!!";
            return;
        }
        bool isEmail = Regex.IsMatch(txtEmail.Text.Trim(), @"\A(?:[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)\Z");
        if (!isEmail)
        {
            lblSignupMsg.Text = "Enter Valid Email ID..";
            lblSignupMsg.ForeColor = System.Drawing.Color.Red;
            return;
        }
        else
        {
            MySqlConnection Cn = new MySqlConnection(ConnStr.ToString());
            Cn.Open();
            MySqlCommand Cmd = new MySqlCommand("Insert Into signup_table values(Default,'','" + txtEmail.Text.Trim() + "','" + txtPassword.Text.Trim() + "',0)", Cn);
            if (Cmd.ExecuteNonQuery() > 0)
            {
                //Send_Mail();
                //lblSignupMsg.Text = "Please Check Email for Verification!!";
                Cn.Close();
                Cn.Dispose();
                Session["Login"] = 1;
                Session["username"] = txtEmail.Text;
                Session["is_signup"] = 1;
                Response.Redirect("service-options.aspx?is_signup=1");
            }
            Cn.Close();
            Cn.Dispose();
        }
    }

    private Boolean Check_Already_Exist()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            MySqlCommand Cmd = new MySqlCommand("select * from signup_table where fldEmail='" + txtEmail.Text.Trim() + "'", Cn);
            using (MySqlDataReader Rdr = Cmd.ExecuteReader())
            {
                Rdr.Read();
                if (Rdr.HasRows == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }

    protected void Send_Mail()
    {
        MailAddress mlfrom = new MailAddress("portljob@gmail.com");
        MailAddress mlTo = new MailAddress(txtEmail.Text);
        MailMessage mymsg = new MailMessage(mlfrom, mlTo);
        mymsg.IsBodyHtml = true;
        mymsg.Subject = "Mustang Storage Email Verification";
        string encryptedstring = clsEncryption.Encrypt(txtEmail.Text, "password");
        string myUrl = "http://mustang-storage.com/verification.aspx?id=" + encryptedstring;
        mymsg.Body = "Thanks for register in Mustang Storage.<br><br> Click on link to complete verification process " + myUrl;
        //mymsg.Body = randomabc;
        SmtpClient smptc = new SmtpClient("smtp.gmail.com", 587);
        smptc.UseDefaultCredentials = false;
        smptc.EnableSsl = true;
        smptc.Credentials = new NetworkCredential("portljob", "gippy@jobportal");
        //smptc.Credentials = new NetworkCredential( "portljob", "livechat136");
        smptc.Send(mymsg);
    }

}
