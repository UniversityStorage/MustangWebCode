﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;
using System.Net.Mail;
using System.Net;
using System.Text.RegularExpressions;

public partial class _forgotpwd : System.Web.UI.Page 
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //}
    //protected void Send_Mail()
    //{
    //    MailAddress mlfrom = new MailAddress("portljob@gmail.com");
    //    MailAddress mlTo = new MailAddress(txtEmail.Text);
    //    MailMessage mymsg = new MailMessage(mlfrom, mlTo);
    //    mymsg.IsBodyHtml = true;
    //    mymsg.Subject = "Mustang Storage Email Verification";
    //    string encryptedstring = clsEncryption.Encrypt(txtEmail.Text,"password");
    //    string myUrl = "http://hfcsrania.in/verification.aspx?id=" + encryptedstring;
    //    mymsg.Body = "Thanks for register in Mustang Storage.<br><br> Click on link to complete verification process " + myUrl;
    //    //mymsg.Body = randomabc;
    //    SmtpClient smptc = new SmtpClient("smtp.gmail.com", 587);
    //    smptc.UseDefaultCredentials = false;
    //    smptc.EnableSsl = true;
    //    smptc.Credentials = new NetworkCredential("portljob", "gippy@jobportal");
    //    //smptc.Credentials = new NetworkCredential( "portljob", "livechat136");
    //    smptc.Send(mymsg);
    //}

   
}
