﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class SignupBillingInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LinkButton varBtnSkip = (LinkButton)this.BilInfo.FindControl("btnSkip");
            varBtnSkip.Visible = true;

            Button varBtnOrder = (Button)this.BilInfo.FindControl("btnPlaceOrder");
            varBtnOrder.Visible = true;

            HiddenField varHidAmt = (HiddenField)this.BilInfo.FindControl("hidAmt");
            varHidAmt.Value = Request.QueryString["tot"];

            Panel varPnl = (Panel)this.BilInfo.FindControl("pnlChain");
            varPnl.Visible = true;

            
        }
    }
}
