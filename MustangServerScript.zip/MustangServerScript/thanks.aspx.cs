﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class thanks : System.Web.UI.Page
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Login"] == null)
        {
            Response.Redirect("credentials.aspx");
        }
        else
        {
            Populate_Data();
            Bind_Controls();
        }
    }

    private void Bind_Controls()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string sSql = "select * from billing_info_table where flduser='" + Session["username"].ToString() + "'";
            MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                txtCardName.Text = Rdr[1].ToString();
                txtBillingAddress.Text = Rdr[2].ToString();
                txtZip.Text = Rdr[3].ToString();
                txtCardNo.Text = Rdr[4].ToString();
                txtCardCode.Text = Rdr[5].ToString();
                txtMonth.Text = Rdr[6].ToString();
                txtYear.Text = Rdr[7].ToString();
            }
            Rdr.Close();
        }
    }

    private void Populate_Data()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            double dblAmt = 0;
            DataTable Dt = clsCommon.ExecuteSql("select * from order_table where order_id='" +  Session["orderid"].ToString() + "'");
            if (Dt.Rows.Count > 0)
            {
                if (Convert.ToInt32(Dt.Rows[0][4].ToString()) > 0)
                {
                    pnlSig.Visible = true;
                    txtSigBox.Text = Dt.Rows[0][4].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][4].ToString()) * 34.99;
                }

                if (Convert.ToInt32(Dt.Rows[0][5].ToString()) > 0)
                {
                    pnlXLBox.Visible = true;
                    txtXlBox.Text = Dt.Rows[0][5].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][5].ToString()) * 49.99;
                }

                if (Convert.ToInt32(Dt.Rows[0][6].ToString()) > 0)
                {
                    pnlWard.Visible = true;
                    txtWardrobe.Text = Dt.Rows[0][6].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][6].ToString()) * 64.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][7].ToString()) > 0)
                {
                    pnlPoster.Visible = true;
                    txtPoster.Text = Dt.Rows[0][7].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][7].ToString()) * 19.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][8].ToString()) > 0)
                {
                    pnlMedBin.Visible = true;
                    txtMedItmBin.Text = Dt.Rows[0][8].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][8].ToString()) * 29.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][9].ToString()) > 0)
                {
                    pnlMedFridge.Visible = true;
                    txtMedItmFridge.Text = Dt.Rows[0][9].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][9].ToString()) * 29.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][10].ToString()) > 0)
                {
                    pnlMedLugg.Visible = true;
                    txtMedItmLugg.Text = Dt.Rows[0][10].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][10].ToString()) * 29.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][11].ToString()) > 0)
                {
                    pnlMedTrunk.Visible = true;
                    txtMedItmTrunk.Text = Dt.Rows[0][11].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][11].ToString()) * 29.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][12].ToString()) > 0)
                {
                    pnlRug.Visible = true;
                    txtMedItmRug.Text = Dt.Rows[0][12].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][12].ToString()) * 29.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][13].ToString()) > 0)
                {
                    pnlLBin.Visible = true;
                    txtLargeItmBin.Text = Dt.Rows[0][13].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][13].ToString()) * 39.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][14].ToString()) > 0)
                {
                    pnlLFridge.Visible = true;
                    txtLargeItmFridge.Text = Dt.Rows[0][14].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][14].ToString()) * 39.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][15].ToString()) > 0)
                {
                    pnlLargeLugg.Visible = true;
                    txtLargeItmLugg.Text = Dt.Rows[0][15].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][15].ToString()) * 39.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][16].ToString()) > 0)
                {
                    pnlLTrunk.Visible = true;
                    txtLargeItmTrunk.Text = Dt.Rows[0][16].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][16].ToString()) * 39.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][17].ToString()) > 0)
                {
                    pnlTV33.Visible = true;
                    txtTv33.Text = Dt.Rows[0][17].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][17].ToString()) * 39.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][18].ToString()) > 0)
                {
                    pnlXLbin.Visible = true;
                    txtXlBin.Text = Dt.Rows[0][18].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][18].ToString()) * 49.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][19].ToString()) > 0)
                {
                    pnlXLfridge.Visible = true;
                    txtXlFridge.Text = Dt.Rows[0][19].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][19].ToString()) * 49.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][20].ToString()) > 0)
                {
                    pnlXLlugg.Visible = true;
                    txtXlLugg.Text = Dt.Rows[0][20].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][20].ToString()) * 49.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][21].ToString()) > 0)
                {
                    pnlXLTrunk.Visible = true;
                    txtXlTrunk.Text = Dt.Rows[0][21].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][21].ToString()) * 49.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][22].ToString()) > 0)
                {
                    pnlTv44.Visible = true;
                    txtTv44.Text = Dt.Rows[0][22].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][22].ToString()) * 49.99;
                }
                if (Convert.ToInt32(Dt.Rows[0][23].ToString()) > 0)
                {
                    pnlChair.Visible = true;
                    txtChair.Text = Dt.Rows[0][23].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][23].ToString()) * 20;
                }
                if (Convert.ToInt32(Dt.Rows[0][24].ToString()) > 0)
                {
                    pnlLamp.Visible = true;
                    txtLamp.Text = Dt.Rows[0][24].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][24].ToString()) * 30;
                }
                if (Convert.ToInt32(Dt.Rows[0][25].ToString()) > 0)
                {
                    pnlMirror.Visible = true;
                    txtMirror.Text = Dt.Rows[0][25].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][25].ToString()) * 20;
                }
                if (Convert.ToInt32(Dt.Rows[0][26].ToString()) > 0)
                {
                    pnlBike.Visible = true;
                    txtBike.Text = Dt.Rows[0][26].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][26].ToString()) * 50;
                }
                if (Convert.ToInt32(Dt.Rows[0][27].ToString()) > 0)
                {
                    pnlmatt.Visible = true;
                    txtMatt.Text = Dt.Rows[0][27].ToString();
                    dblAmt += Convert.ToDouble(Dt.Rows[0][27].ToString()) * 140;
                }
            }
            txtTotal.Text = dblAmt.ToString();
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.Clear();
        Response.Redirect("index.html");
    }

   
}
