﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;


public partial class UserControl_DeliveryInfo : System.Web.UI.UserControl
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
            return;
        }

        if (!IsPostBack)
        {
            Bind_Controls();
            Fill_Time();
        }
    }

    protected void btnSkip_Click(object sender, EventArgs e)
    {
        Response.Redirect("SignupBillingInfo.aspx?tot=" + hidAmt.Value.ToString());
    }

    private void Fill_Time()
    {
        dd_del_time.Items.Add("9:00 AM");
        dd_del_time.Items.Add("9:30 AM");
        dd_del_time.Items.Add("10:00 AM");
        dd_del_time.Items.Add("10:30 AM");
        dd_del_time.Items.Add("11:00 AM");
        dd_del_time.Items.Add("11:30 AM");
        dd_del_time.Items.Add("12:00 AM");
        dd_del_time.Items.Add("12:30 AM");
        dd_del_time.Items.Add("1:00 PM");
        dd_del_time.Items.Add("1:30 PM");
        dd_del_time.Items.Add("2:00 PM");
        dd_del_time.Items.Add("2:30 PM");
        dd_del_time.Items.Add("3:00 PM");
        dd_del_time.Items.Add("3:30 PM");
        dd_del_time.Items.Add("4:00 PM");
        dd_del_time.Items.Add("4:30 PM");
        dd_del_time.Items.Add("5:00 PM");
        dd_del_time.Items.Add("5:30 PM");
    }

    private void Bind_Controls()
    {
        if (Session.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
            return;
        }

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string sSql = "select * from delivery_info_table where flduser='" + Session["username"].ToString() + "'";
            MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                if ((string)Rdr[1] == "OnCampus")
                {
                    radOnCampus.Checked = true;
                    div_OnCampus.Style["display"] = "block";
                    div_OffCampus.Style["display"] = "none";
                }
                else
                {
                    radOffCampus.Checked = true;
                    div_OnCampus.Style["display"] = "none";
                    div_OffCampus.Style["display"] = "block";
                }
                dd_Uni.Text = Rdr[2].ToString();
                dd_Dorm.Text = Rdr[3].ToString();
                txtRoom.Text = Rdr[4].ToString();
                txtAddress.Text = Rdr[5].ToString();
                txtApartment.Text = Rdr[6].ToString();
                txtBuilding.Text = Rdr[7].ToString();
                txtDate.Text = Rdr[8].ToString();
                dd_del_time.Text = Rdr[9].ToString();
                txtLocation.Text = Rdr[10].ToString();
                dd_HowHear.Text = Rdr[11].ToString();
            }
            Rdr.Close();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
            return;
        }

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            try
            {
                Cn.Open();
                string sSql = "delete from delivery_info_table where flduser='" + Session["username"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand();
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                string strDelivType = "";
                if (radOnCampus.Checked == true)
                {
                    strDelivType = "OnCampus";
                }
                else
                {
                    strDelivType = "OffCampus";
                }
                sSql = "insert into delivery_info_table  values('" + Session["username"].ToString() + "','" + strDelivType.ToString() + "','" + dd_Uni.Text.Trim() + "','" + dd_Dorm.Text.Trim() + "','" + txtRoom.Text.Trim() + "','" + txtAddress.Text + "','" + txtApartment.Text + "','" + txtBuilding.Text + "','" + txtDate.Text + "','" + dd_del_time.Text + "','" + txtLocation.Text + "','" + dd_HowHear.Text + "')";
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                if (Session["is_signup"] != null)
                {
                    Response.Redirect("SignupBillingInfo.aspx?tot=" + hidAmt.Value.ToString());
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Error:", "alert('Error : " + ex.Message.ToString() + "');", true);
            }
        }

    }
}
