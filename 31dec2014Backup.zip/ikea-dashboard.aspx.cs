﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class ikeadashboard : System.Web.UI.Page
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Login"] == null)
        {
            Response.Redirect("credentials.aspx");
        }
        if (!IsPostBack)
        {
            SetInitialRow();
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.Clear();
        Response.Redirect("index.html");
    }

    private void SetInitialRow()
    {

        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));

        dr = dt.NewRow();
        dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dt.Rows.Add(dr);

        //Store the DataTable in ViewState
        ViewState["CurrentTable"] = dt;

        Gridview1.DataSource = dt;
        Gridview1.DataBind();
    }

    private void AddNewRowToGrid()
    {

        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    //extract the TextBox values
                    TextBox box1 = (TextBox)Gridview1.Rows[rowIndex].Cells[1].FindControl("TextBox1");
                    TextBox box2 = (TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("TextBox2");

                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = i + 1;
                    drCurrentRow["Column1"] = box1.Text;
                    drCurrentRow["Column2"] = box2.Text;

                    rowIndex++;
                }

                //add new row to DataTable
                dtCurrentTable.Rows.Add(drCurrentRow);
                //Store the current data to ViewState
                ViewState["CurrentTable"] = dtCurrentTable;

                //Rebind the Grid with the current data
                Gridview1.DataSource = dtCurrentTable;
                Gridview1.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }

    private void SetPreviousData()
    {

        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 1; i < dt.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)Gridview1.Rows[rowIndex].Cells[1].FindControl("TextBox1");
                    TextBox box2 = (TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("TextBox2");

                    box1.Text = dt.Rows[i]["Column1"].ToString();
                    box2.Text = dt.Rows[i]["Column2"].ToString();

                    rowIndex++;

                }
            }
        }
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }

    private void  Save_Rec()
    {
        string strOrderId = Generate_Order_Id(5);
        Session["orderid"] = strOrderId;
        foreach (GridViewRow row in Gridview1.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
                TextBox textBoxSr = row.FindControl("TextBox1") as TextBox;
                TextBox textDesc= row.FindControl("TextBox2") as TextBox;
                if (textBoxSr.Text != "")
                {
                    using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
                    {
                        Cn.Open();
                        MySqlCommand Cmd=new MySqlCommand("insert into ikea_order_table values(Default,'" + textBoxSr.Text.Trim() + "','" +  textDesc.Text.Trim() + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "',1,'" + strOrderId.ToString() + "','" + Session["username"].ToString() + "')",Cn);
                        Cmd.ExecuteNonQuery();
                        //Response.Redirect("ikea-dashboard.aspx"); 
                    }
                }
            }
        }
    }

    private string Generate_Order_Id(int length)
    {
    lblJump:
        string valid = "1234567890";
        string res = "";
        Random rnd = new Random();
        while (0 < length--)
            res += valid[rnd.Next(valid.Length)];

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string strComm = "select order_id from ikea_order_table where order_id<>'" + res.ToString() + "'";
            MySqlCommand Cmd = new MySqlCommand(strComm, Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                if (Rdr[0].ToString() == res.ToString())
                {
                    goto lblJump;
                }
            }
            Rdr.Close();
            Rdr.Dispose();
        }
        return res;
    }

    protected void btnCompleteOrder_Click(object sender, EventArgs e)
    { 
        TextBox varTxtFirstName = (TextBox)this.BasicInfo.FindControl("txtFirstName");
        TextBox varTxtLastName = (TextBox)this.BasicInfo.FindControl("txtLastName");
        TextBox varTxtPhArea= (TextBox)this.BasicInfo.FindControl("txtPhAreaCode");
        TextBox varTxtPhNo= (TextBox)this.BasicInfo.FindControl("txtPhNo");
        TextBox varTxtAltArea = (TextBox)this.BasicInfo.FindControl("txtAltAreaCode");
        TextBox varTxtAltPhNo = (TextBox)this.BasicInfo.FindControl("txtAltPhNo");
        TextBox varTxtSchoolEmail = (TextBox)this.BasicInfo.FindControl("txtScEmail");
        TextBox varTxtParentEmail = (TextBox)this.BasicInfo.FindControl("txtParentEmail");

        if (varTxtFirstName.Text == "" || varTxtFirstName.Text == "First Name")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return; 
        }
        if (varTxtLastName.Text == "" || varTxtLastName.Text == "Last Name")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtPhArea.Text == "" || varTxtPhArea.Text == "Area Code")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtPhNo.Text == "" || varTxtPhNo.Text == "Phone Number")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtAltArea.Text == "" || varTxtAltArea.Text == "Area Code")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtAltPhNo.Text == "" || varTxtAltPhNo.Text == "Phone Number")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtSchoolEmail.Text == "" || varTxtSchoolEmail.Text == "ex-myname@example.com")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtParentEmail.Text == "" || varTxtParentEmail.Text == "ex-myname@example.com")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        //------------------------------Delivery----------------
        TextBox varTxtDelDate = (TextBox)this.BasicInfo.FindControl("txtDate");
        TextBox varTxtDelTime = (TextBox)this.BasicInfo.FindControl("dd_del_time");
        if (varTxtDelDate.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }

        if (varTxtDelTime.Text == "" || varTxtDelTime.Text == "--Select--")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        //-------------------------BILLING------------------------
        TextBox varTxtCardName = (TextBox)this.BillingInfo.FindControl("txtCardName");
        TextBox varTxtBillAdd = (TextBox)this.BillingInfo.FindControl("txtBillingAddress");
        TextBox varTxtZIP = (TextBox)this.BillingInfo.FindControl("txtZip");
        TextBox varTxtCardNo = (TextBox)this.BillingInfo.FindControl("txtCardNo");
        TextBox varTxtCSV = (TextBox)this.BillingInfo.FindControl("txtCardCode");
        TextBox varTxtExpMonth = (TextBox)this.BillingInfo.FindControl("txtMonth");
        TextBox varTxtExpYear = (TextBox)this.BillingInfo.FindControl("txtYear");
        if (varTxtCardName.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtBillAdd.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtZIP.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtCardNo.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtCSV.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtExpMonth.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }
        if (varTxtExpYear.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Fields');", true);
            id_chkout_wrapper.Style["display"] = "block";
            return;
        }

        Save_Rec();
        int myAmt = 100;
        string encryptedstring = clsEncryption.Encrypt(myAmt.ToString(), "billamount");
        Response.Redirect("Payment.aspx?Total=" + encryptedstring + "&ordertype=ikea");
    }
}
