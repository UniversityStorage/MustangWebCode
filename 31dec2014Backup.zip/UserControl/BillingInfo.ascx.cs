﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class UserControl_BillingInfo : System.Web.UI.UserControl
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
            return;
        }

        if (!IsPostBack)
        {
            Bind_Controls();
        }
    }

    protected void btnSkip_Click(object sender, EventArgs e)
    {
        Session.Remove("is_signup");
        Response.Redirect("dashboard.aspx");
    }

    private Boolean Check_Pickup_Validation()
    {
        if (Session.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
            return false;
        }
        else
        {
            using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
            {
                Cn.Open();
                string sSql = "select * from pickup_info_table where flduser='" + Session["username"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
                Boolean boolChk = false;
                using (MySqlDataReader Rdr = Cmd.ExecuteReader())
                {
                    Rdr.Read();
                    if (Rdr.HasRows == true)
                    {
                        if ((string)Rdr["CampusType"] == "OffCampus")
                        {
                            if ((string)Rdr["fldaddress"] == string.Empty)
                            {
                                boolChk = true;
                            }
                        }
                        if ((string)Rdr["CampusType"] == "OnCampus")
                        {
                            if ((string)Rdr["fldroom"] == string.Empty)
                            {
                                boolChk = true;
                            }
                        }
                        if ((string)Rdr["fldcity"] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr["fldstate"] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr["fldzip"] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr["pick_time"] == string.Empty)
                        {
                            boolChk = true;
                        }
                    }

                    if (Rdr.HasRows == false)
                    {
                        boolChk = true;
                    }

                    if (boolChk == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
    }

    private Boolean Check_BasicInfo_Validation()
    {
       
            using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
            {
                Cn.Open();
                string sSql = "select * from basic_info_table where flduser='" + Session["username"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
                Boolean boolChk = false;
                using (MySqlDataReader Rdr = Cmd.ExecuteReader())
                {
                    Rdr.Read();
                    if (Rdr.HasRows == true)
                    {
                        if ((string)Rdr[1] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr[2] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr[3] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr[4] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr[5] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr[6] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr[7] == string.Empty)
                        {
                            boolChk = true;
                        }
                        if ((string)Rdr[8] == string.Empty)
                        {
                            boolChk = true;
                        }
                    }
                    if (Rdr.HasRows == false)
                    {
                        boolChk = true;
                    }

                    if (boolChk == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
    }

    private Boolean Check_Billing_Validations()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string sSql = "select * from billing_info_table where flduser='" + Session["username"].ToString() + "'";
            MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
            Boolean boolChk = false; 
            using (MySqlDataReader Rdr = Cmd.ExecuteReader())
            {
                Rdr.Read();
                if (Rdr.HasRows == true)
                {
                    if ((string)Rdr[1] == string.Empty)
                    {
                        boolChk = true; 
                    }
                    if ((string)Rdr[2] == string.Empty)
                    {
                        boolChk = true;
                    }
                    if ((string)Rdr[3] == string.Empty)
                    {
                        boolChk = true;
                    }
                    if ((string)Rdr[4] == string.Empty)
                    {
                        boolChk = true;
                    }
                    if ((Int32)Rdr[5] == 0)
                    {
                        boolChk = true;
                    }
                    if ((Int32)Rdr[6] == 0)
                    {
                        boolChk = true;
                    }
                    if ((Int32)Rdr[7] == 0)
                    {
                        boolChk = true;
                    }
                }
                if (Rdr.HasRows == false)
                {
                    boolChk = true;
                }

                if (boolChk == true)
                {
                    return true;
                }
                else
                {
                    return false; 
                }
            }
        }
    }

    protected void btnPlaceOrder_Click(object sender, EventArgs e)
    {

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            try
            {
                Cn.Open();
                string sSql = "delete from billing_info_table where flduser='" + Session["username"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand();
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                sSql = "insert into billing_info_table  values('" + Session["username"].ToString() + "','" + txtCardName.Text.Trim() + "','" + txtBillingAddress.Text.Trim() + "','" + txtZip.Text.Trim() + "','" + txtCardNo.Text + "'," + ParseDouble(txtCardCode.Text.Trim()) + "," + ParseDouble(txtMonth.Text.Trim()) + "," + ParseDouble(txtYear.Text.Trim()) + ")";
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                if (Session["is_signup"] != null)
                {
                    Session.Remove("is_signup");
                    //Response.Redirect("dashboard.aspx");
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Error:", "alert('Error : " + ex.Message.ToString() + "');", true);
            }
        }

        if (Check_BasicInfo_Validation() == true)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Complete Basic Information');", true);
            return;
        }

        if (Check_Pickup_Validation() == true)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Complete Pickup Information');", true);
            return; 
        }

        if (Check_Billing_Validations() == true)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Complete Billing Information');", true);
            return; 
        }

        Response.Redirect("Payment.aspx?Total=" + hidAmt.Value.ToString() + "&ordertype=storage&signup=1");
    }

    private void Bind_Controls()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string sSql = "select * from billing_info_table where flduser='" + Session["username"].ToString() + "'";
            MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                txtCardName.Text = Rdr[1].ToString();
                txtBillingAddress.Text = Rdr[2].ToString();
                txtZip.Text = Rdr[3].ToString();
                txtCardNo.Text = Rdr[4].ToString();
                txtCardCode.Text = Rdr[5].ToString();
                txtMonth.Text = Rdr[6].ToString();
                txtYear.Text = Rdr[7].ToString();
            }
            Rdr.Close();
        }
    }

    private double ParseDouble(string value)
    {
        double d = 0;
        if (!double.TryParse(value, out d))
        {
            return 0;
        }
        return d;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
            return;
        }

        if (txtCardName.Text== "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Card Name');", true);
            return;
        }
        if (txtBillingAddress.Text== "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Address');", true);
            return;
        }
        if (txtZip.Text== "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required ZIP');", true);
            return;
        }
        if (txtCardNo.Text== "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Card No');", true);
            return;
        }
        if (txtCardCode.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required CSV');", true);
            return;
        }
        if (txtMonth.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Month');", true);
            return;
        }
        if (txtYear.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please Enter Required Year');", true);
            return;
        }

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            try
            {
                Cn.Open();
                string sSql = "delete from billing_info_table where flduser='" + Session["username"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand();
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                sSql = "insert into billing_info_table  values('" + Session["username"].ToString() + "','" + txtCardName.Text.Trim() + "','" + txtBillingAddress.Text.Trim() + "','" + txtZip.Text.Trim() + "','" + txtCardNo.Text + "'," + ParseDouble(txtCardCode.Text.Trim()) + "," + ParseDouble(txtMonth.Text.Trim()) + "," + ParseDouble(txtYear.Text.Trim()) + ")";
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                if (Session["is_signup"] != null)
                {
                    //Session.Remove("is_signup");
                    //Response.Redirect("dashboard.aspx");
                }
            }
            catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Error:", "alert('Error : " + ex.Message.ToString() + "');", true);
            }
        }
    }

}
