﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class UserControl_basicInfo : System.Web.UI.UserControl
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session.Count == 0)
        //{
        //    ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
        //    return;
        //}

        if (!IsPostBack)
        {
            Bind_Controls();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        //if(Session.Count==0)
        //{
        //    ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
        //}
        //else
        //{
            using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
            {
                try
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session ID: " + Session.SessionID.ToString() + "');", true);

                    Cn.Open();
                    string sSql = "delete from basic_info_table where flduser='" + Session["username"].ToString() + "'";
                    MySqlCommand Cmd = new MySqlCommand();
                    Cmd.CommandText = sSql;
                    Cmd.Connection = Cn;
                    Cmd.ExecuteNonQuery();
                    sSql = "insert into basic_info_table values('" + Session["username"].ToString() + "','" + txtFirstName.Text + "','" + txtLastName.Text + "',";
                    sSql = sSql + "'" + txtPhAreaCode.Text + "','" + txtPhNo.Text + "','" + txtAltAreaCode.Text + "','" + txtAltPhNo.Text + "','" + txtScEmail.Text + "',";
                    sSql = sSql + "'" + txtParentEmail.Text + "')";
                    Cmd.CommandText = sSql;
                    Cmd.Connection = Cn;
                    Cmd.ExecuteNonQuery();
                    if (Session["is_signup"] != null)
                    {
                        Response.Redirect("SignupPickupInfo.aspx?tot=" + hidAmt.Value.ToString());
                    }
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "Error:", "alert('Error : " + ex.Message.ToString() + "');", true);
                }
            }
        //}
    }

    protected void btnSkip_Click(object sender, EventArgs e)
    {
        Response.Redirect("SignupPickupInfo.aspx?tot=" + hidAmt.Value.ToString() );
    }

    private void Bind_Controls()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string sSql = "select * from basic_info_table where flduser='" + Session["username"].ToString() + "'";
            MySqlCommand Cmd = new MySqlCommand(sSql,Cn);
            MySqlDataReader Rdr= Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                txtFirstName.Text = Rdr[1].ToString();
                txtLastName.Text = Rdr[2].ToString();
                txtPhAreaCode.Text = Rdr[3].ToString();
                txtPhNo.Text = Rdr[4].ToString();
                txtAltAreaCode.Text = Rdr[5].ToString();
                txtAltPhNo.Text = Rdr[6].ToString();
                txtScEmail.Text = Rdr[7].ToString();
                txtParentEmail.Text = Rdr[8].ToString();
            }
            Rdr.Close();
        }
    }
}
