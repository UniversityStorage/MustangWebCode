﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class UserControl_what_to_store : System.Web.UI.UserControl
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnOrderNow_Click(object sender, EventArgs e)
    {
        try
        {
            string Total = (Convert.ToDouble(hdnTotal.Value) + Get_Insurence_Amt()).ToString();
            if (Convert.ToDouble(Total) > 0)
            {
                if (Save_Record() == true)
                {
                    //Response.Redirect("Payment.aspx?Total=" + Total);
                    Session["PaymentAmt"] = Total;
                    string encryptedstring = clsEncryption.Encrypt(Total, "billamount");
                    if (HiddenField1.Value == "Signup")
                    {
                        Response.Redirect("SignupBasicInfo.aspx?tot=" + encryptedstring);
                    }
                    else
                    {
                        Response.Redirect("StorageCheckout.aspx?tot=" + encryptedstring);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Error:", "alert('Error : " + ex.Message.ToString() + "');", true);
        }
    }

    private int Get_Insurence_Amt()
    {
        Int32 res = 0;
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string strComm = "select insure_amt from pickup_info_table where flduser='" + Session["username"].ToString() + "' And is_insurence=1";
            MySqlCommand Cmd = new MySqlCommand(strComm, Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                res = Convert.ToInt32(Rdr[0].ToString());
            }
            Rdr.Close();
            Rdr.Dispose();
        }

        return res;        
    }

    private Boolean  Save_Record()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            foreach (TextBox tb in this.Controls.OfType<TextBox>())
            {
                if (tb.Text == String.Empty)
                {
                    tb.Text = "0";
                }
            }
            string strOrderId=Generate_Order_Id(5);
            int intPckPeanut = 0;
            if (chkPeanuts.Checked == true)
            {
                intPckPeanut = 1; 
            }
            int intBubbleWrap = 0;
            if (chkBubble.Checked == true)
            {
                intBubbleWrap = 1;
            }
            int intTvBox = 0;
            if (chkTvBox.Checked == true)
            {
                intTvBox = 1;
            }
            string strIns = "insert into order_table values(Default,'" + strOrderId.ToString() + "','" + Session["username"].ToString() + "',";
            strIns = strIns + "'" + DateTime.Now.ToString("yyyy-MM-dd") + "'," + txtSigBox.Text.Trim() + "," + txtXlBox.Text.Trim() + ",";
            strIns = strIns + txtWardrobe.Text.Trim() + "," + txtPoster.Text.Trim() + "," + txtMedItmBin.Text.Trim() + ",0,";
            strIns = strIns + txtMedItmLugg.Text.Trim() + "," + txtMedItmTrunk.Text.Trim() + "," + txtMedItmRug.Text.Trim() + ",";
            strIns = strIns + txtLargeItmBin.Text.Trim() + "," + txtLargeItmFridge.Text.Trim() + "," + txtLargeItmLugg.Text.Trim() + ",";
            strIns = strIns + txtLargeItmTrunk.Text.Trim() + "," + txtTv33.Text.Trim() + "," + txtXlBin.Text.Trim() + "," + txtXlFridge.Text.Trim() + ",";
            strIns = strIns + txtXlLugg.Text.Trim() + "," + txtXlTrunk.Text.Trim() + "," + txtTv44.Text.Trim() + "," + txtChair.Text.Trim() + ",";
            strIns = strIns + txtLamp.Text.Trim() + "," + txtMirror.Text.Trim() + "," + txtBike.Text.Trim() + "," + txtMatt.Text.Trim() + ",0," + txtGolf.Text.Trim() + ",";
            strIns = strIns + txtRecl.Text.Trim() + "," + intPckPeanut + "," + intBubbleWrap + "," + intTvBox + ")";
            MySqlCommand Cmd = new MySqlCommand(strIns,Cn);
            Cmd.ExecuteNonQuery();
            Session["orderid"] = strOrderId.ToString();
            Cn.Close();
            return true; 
        }
    }

    private string Generate_Order_Id(int length)
    {
        lblJump:
        string valid = "1234567890";
        string res = "";
        Random rnd = new Random();
        while (0 < length--)
            res += valid[rnd.Next(valid.Length)];

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string strComm="select order_id from order_table where order_id<>'" + res.ToString() + "'"; 
            MySqlCommand Cmd = new MySqlCommand(strComm,Cn);
            MySqlDataReader Rdr=Cmd.ExecuteReader();
            Rdr.Read();
            if(Rdr.HasRows==true)
            {
                if (Rdr[0].ToString() == res.ToString())
                {
                    goto lblJump;
                }
            }
            Rdr.Close();
            Rdr.Dispose();
        }
        
        return res;        
    }
}
