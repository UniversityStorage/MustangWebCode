﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class UserControl_pickupInfo : System.Web.UI.UserControl
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Fill_Dorm();
            Bind_Controls();
            Fill_Time();
            Fill_Insurence();
        }
    }

    protected void btnSkip_Click(object sender, EventArgs e)
    {
        Response.Redirect("SignupDeliveryInfo.aspx?tot=" + hidAmt.Value.ToString());
    }

    private void Fill_Time()
    {

        txtPickTime.Items.Add("8:00 AM");
        txtPickTime.Items.Add("8:30 AM");
        txtPickTime.Items.Add("9:00 AM");
        txtPickTime.Items.Add("9:30 AM");
        txtPickTime.Items.Add("10:00 AM");
        txtPickTime.Items.Add("10:30 AM");
        txtPickTime.Items.Add("11:00 AM");
        txtPickTime.Items.Add("11:30 AM");
        txtPickTime.Items.Add("12:00 AM");
        txtPickTime.Items.Add("12:30 AM");
        txtPickTime.Items.Add("1:00 PM");
        txtPickTime.Items.Add("1:30 PM");
        txtPickTime.Items.Add("2:00 PM");
        txtPickTime.Items.Add("2:30 PM");
        txtPickTime.Items.Add("3:00 PM");
        txtPickTime.Items.Add("3:30 PM");
        txtPickTime.Items.Add("4:00 PM");
        txtPickTime.Items.Add("4:30 PM");
        txtPickTime.Items.Add("5:00 PM");
        txtPickTime.Items.Add("5:30 PM");

        dd_addi_pick_time.Items.Add("8:00 AM");
        dd_addi_pick_time.Items.Add("8:30 AM");
        dd_addi_pick_time.Items.Add("9:00 AM");
        dd_addi_pick_time.Items.Add("9:30 AM");
        dd_addi_pick_time.Items.Add("10:00 AM");
        dd_addi_pick_time.Items.Add("10:30 AM");
        dd_addi_pick_time.Items.Add("11:00 AM");
        dd_addi_pick_time.Items.Add("11:30 AM");
        dd_addi_pick_time.Items.Add("12:00 AM");
        dd_addi_pick_time.Items.Add("12:30 AM");
        dd_addi_pick_time.Items.Add("1:00 PM");
        dd_addi_pick_time.Items.Add("1:30 PM");
        dd_addi_pick_time.Items.Add("2:00 PM");
        dd_addi_pick_time.Items.Add("2:30 PM");
        dd_addi_pick_time.Items.Add("3:00 PM");
        dd_addi_pick_time.Items.Add("3:30 PM");
        dd_addi_pick_time.Items.Add("4:00 PM");
        dd_addi_pick_time.Items.Add("4:30 PM");
        dd_addi_pick_time.Items.Add("5:00 PM");
        dd_addi_pick_time.Items.Add("5:30 PM");

        dd_addi_del_time.Items.Add("9:00 AM");
        dd_addi_del_time.Items.Add("9:30 AM");
        dd_addi_del_time.Items.Add("10:00 AM");
        dd_addi_del_time.Items.Add("10:30 AM");
        dd_addi_del_time.Items.Add("11:00 AM");
        dd_addi_del_time.Items.Add("11:30 AM");
        dd_addi_del_time.Items.Add("12:00 AM");
        dd_addi_del_time.Items.Add("12:30 AM");
        dd_addi_del_time.Items.Add("1:00 PM");
        dd_addi_del_time.Items.Add("1:30 PM");
        dd_addi_del_time.Items.Add("2:00 PM");
        dd_addi_del_time.Items.Add("2:30 PM");
        dd_addi_del_time.Items.Add("3:00 PM");
        dd_addi_del_time.Items.Add("3:30 PM");
        dd_addi_del_time.Items.Add("4:00 PM");
        dd_addi_del_time.Items.Add("4:30 PM");
        dd_addi_del_time.Items.Add("5:00 PM");
        dd_addi_del_time.Items.Add("5:30 PM");

    }

    private void Fill_Insurence()
    {
        ListItem itm1 = new ListItem();
        itm1.Text ="$100($5 extra)";
        itm1.Value ="5";
        txtInsureAmt.Items.Add(itm1);

        ListItem itm2 = new ListItem();
        itm2.Text = "$200($10 extra)";
        itm2.Value = "10";
        txtInsureAmt.Items.Add(itm2);

        ListItem itm3 = new ListItem();
        itm3.Text = "$300($15 extra)";
        itm3.Value = "15";
        txtInsureAmt.Items.Add(itm3);

        ListItem itm4 = new ListItem();
        itm4.Text = "$400($20 extra)";
        itm4.Value = "20";
        txtInsureAmt.Items.Add(itm4);

        ListItem itm5 = new ListItem();
        itm5.Text = "$500($25 extra)";
        itm5.Value = "25";
        txtInsureAmt.Items.Add(itm5);

        ListItem itm6 = new ListItem();
        itm6.Text = "$600($30 extra)";
        itm6.Value = "30";
        txtInsureAmt.Items.Add(itm6);

        ListItem itm7 = new ListItem();
        itm7.Text = "$700($35 extra)";
        itm7.Value = "35";
        txtInsureAmt.Items.Add(itm7);

        ListItem itm8 = new ListItem();
        itm8.Text = "$800($40 extra)";
        itm8.Value = "40";
        txtInsureAmt.Items.Add(itm8);

        ListItem itm9 = new ListItem();
        itm9.Text = "$900($45 extra)";
        itm9.Value = "45";
        txtInsureAmt.Items.Add(itm9);

        ListItem itm10 = new ListItem();
        itm10.Text = "$1000($50 extra)";
        itm10.Value = "50";
        txtInsureAmt.Items.Add(itm10);
    }

    private void Fill_Dorm()
    {
        dd_Dorm.Items.Add("Armstrong Commons");
        dd_Dorm.Items.Add("Boaz Commons");
        dd_Dorm.Items.Add("Cockrell-McIntosh Commons");
        dd_Dorm.Items.Add("Crum Commons");
        dd_Dorm.Items.Add("Daniel House");
        dd_Dorm.Items.Add("Hawk Hall");
        dd_Dorm.Items.Add("Kathy Crow Commons");
        dd_Dorm.Items.Add("Loyd Commons");
        dd_Dorm.Items.Add("Martin Hall");
        dd_Dorm.Items.Add("Mary Hay Commons");
        dd_Dorm.Items.Add("McElvaney Commons");
        dd_Dorm.Items.Add("Moore Hall");
        dd_Dorm.Items.Add("Morrison-McGinnis Commons");
        dd_Dorm.Items.Add("Perkins Hall");
        dd_Dorm.Items.Add("Peyton Commons");
        dd_Dorm.Items.Add("SMU Service House");
        dd_Dorm.Items.Add("Shuttles Commons");
        dd_Dorm.Items.Add("Smith Hall");
        dd_Dorm.Items.Add("Virginia-Snider Commons");
        dd_Dorm.Items.Add("Ware Residential Commons"); 
    }

    private void Bind_Controls()
    {
        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string sSql = "select * from pickup_info_table where flduser='" + Session["username"].ToString() + "'";
            MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            Rdr.Read();
            if (Rdr.HasRows == true)
            {
                if ((string)Rdr[1] == "OnCampus")
                {
                    radOnCampus.Checked = true;
                    div_OnCampus.Style["display"] = "block";
                    div_OffCampus.Style["display"] = "none";
                }
                else
                {
                    radOffCampus.Checked = true;
                    div_OnCampus.Style["display"] = "none";
                    div_OffCampus.Style["display"] = "block";
                }
                dd_Dorm.Text = Rdr[2].ToString();
                txtRoom.Text = Rdr[3].ToString();
                txtAddress.Text = Rdr[4].ToString();
                txtApartment.Text = Rdr[5].ToString();
                txtBuilding.Text = Rdr[6].ToString();
                txtCity.Text = Rdr[7].ToString();
                dd_state.Text  = Rdr[8].ToString();
                txtZIP.Text = Rdr[9].ToString();
                txtPickDate.Text = Rdr[10].ToString();
                txtPickTime.Text = Rdr[11].ToString();
                if ((Int16)Rdr[12] == 1)
                {
                    chkPickFrn.Checked = true;
                    div_frn_name.Style["display"] = "block";
                    txtFrnName.Text = Rdr[20].ToString();
                }
                else
                { 
                    chkPickFrn.Checked = false;
                    div_frn_name.Style["display"] = "none";
                }
                if ((Int16)Rdr[13] == 1)
                {
                    chkInsure.Checked = true;
                    div_insure_amt.Style["display"] = "block";
                }
                else
                {
                    chkInsure.Checked = false;
                    div_insure_amt.Style["display"] = "none";
                }
                if ((Int16)Rdr["pick_extra_pick_deliv"] == 1)
                {
                    chkExtraPick.Checked = true;
                    div_extra_pick.Style["display"] = "block";
                }
                else
                {
                    chkExtraPick.Checked = false;
                    div_extra_pick.Style["display"] = "none";
                }

                //string selId=Rdr[14].ToString();
                //txtInsureAmt.SelectedIndex = selId; 
                //txtInsureAmt.SelectedValue = Rdr[14].ToString();
            }
            Rdr.Close();
        }
    }

    private double ParseDouble(string value)
    {
        double d = 0;
        if (!double.TryParse(value, out d))
        {
            return 0;
        }
        return d;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Session State Closed');", true);
            return;
        }

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            try
            {
                Cn.Open();
                string sSql = "delete from pickup_info_table where flduser='" + Session["username"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand();
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                string strCampusType = "";
                int intFrn = 0;
                int intInsure = 0;
                int intExtraPick = 0;
                if (radOnCampus.Checked == true)
                {
                    strCampusType = "OnCampus";
                }
                else
                {
                    strCampusType = "OffCampus";
                }
                if (chkPickFrn.Checked == true)
                {
                    intFrn = 1;
                }
                if (chkInsure.Checked == true)
                {
                    intInsure = 1;
                }
                if (chkExtraPick.Checked == true)
                {
                    intExtraPick = 1;
                }

                sSql = "insert into pickup_info_table values('" + Session["username"].ToString() + "','" + strCampusType.ToString() + "','" + dd_Dorm.Text + "','" + txtRoom.Text + "',";
                sSql = sSql + "'" + txtAddress.Text + "','" + txtApartment.Text + "','" + txtBuilding.Text + "','" + txtCity.Text + "','" + dd_state.Text + "',";
                sSql = sSql + "'" + txtZIP.Text + "','" + txtPickDate.Text + "','" + txtPickTime.Text + "'," + intFrn + "," + intInsure + "," + ParseDouble(txtInsureAmt.Text) + "," + intExtraPick + ",'" + txtAddiDelDate.Text + "','" + dd_addi_del_time.Text + "','" + txtAddiPickDate.Text + "','" + dd_addi_pick_time.Text + "','" + txtFrnName.Text + "')";
                Cmd.CommandText = sSql;
                Cmd.Connection = Cn;
                Cmd.ExecuteNonQuery();
                if (Session["is_signup"] != null)
                {
                    Response.Redirect("SignupDeliveryInfo.aspx?tot=" + hidAmt.Value.ToString());
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Error:", "alert('Error : " + ex.Message.ToString() + "');", true);
            }
        }
    }
}
