﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

public partial class _Default : System.Web.UI.Page
{
    static string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        Fill_Banner();
        Fill_Testimonials();
    }

    private void Fill_Banner()
    {
        for (int x = 1; x <= 6; x++)
        {
            Session.Remove("imgsrc" + x);
        }

        using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
        {
            Cn.Open();
            string strComm = "select * from banner_images_table order by id";
            MySqlCommand Cmd = new MySqlCommand(strComm, Cn);
            MySqlDataReader Rdr = Cmd.ExecuteReader();
            int I = 1;
            //string[] imgSrc1=new string[10] ;
            while (Rdr.Read())
            {
                Session["imgsrc" + I] = "banner-images/" + Rdr[1].ToString();
                //imgSrc1[I] = Rdr[1].ToString();
                I += 1;
            }
            Rdr.Close();
            Rdr.Dispose();
        }
    }

    private void Fill_Testimonials()
    {
        DataTable Dt = clsCommon.ExecuteSql("select * from testimonial_table where is_selected=1 order by id");
        Repeater1.DataSource = Dt;
        Repeater1.DataBind();
    }
}
