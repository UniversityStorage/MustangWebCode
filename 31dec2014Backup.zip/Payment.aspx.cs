using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Stripe;
using Newtonsoft;
using MySql.Data.MySqlClient;
using System.Configuration;

    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string decryptedstring = clsEncryption.Decrypt(Request.QueryString["Total"], "billamount");
            //lblTotalValue.Text = decryptedstring;

            //txtTotAmt.Value = clsEncryption.Decrypt(Request.QueryString["Total"], "billamount");

            if (!IsPostBack)
            {
                Bind_Controls();
            }

            txtTotAmt.Value = Session["PaymentAmt"].ToString(); 
            if (Request.QueryString["signup"] == "1")
            {
                pnlChain.Visible = true;
            }
            else
            {
                pnlChain.Visible = false;
                hlfChain.Visible = true;
            }
        }

        private void Bind_Controls()
        {
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
            {
                Cn.Open();
                string sSql = "select * from billing_info_table where flduser='" + Session["username"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand(sSql, Cn);
                MySqlDataReader Rdr = Cmd.ExecuteReader();
                Rdr.Read();
                if (Rdr.HasRows == true)
                { 
                    txtCardName.Value = Rdr[1].ToString();
                    txtCardNumber.Value = Rdr[4].ToString();
                    txtCVV.Value = Rdr[5].ToString();
                    drpMonth.Text = Rdr[6].ToString();
                    drpYear.Text = Rdr[7].ToString();
                }
                Rdr.Close();
            }
        }

        protected void btnPayment_Click(object sender, EventArgs e) 
        {
            try
            {
                if (chkTerms.Checked == true)
                {
                    var myCharge = new StripeChargeCreateOptions();

                    //myCharge.Amount = Int32.Parse(lblTotalValue.Text);
                    myCharge.Amount = Int32.Parse(txtTotAmt.Value)*100;//converted from cents to USD                   
                    myCharge.Currency = "usd";
                    // set this if you want to
                    //myCharge.Description = "Mustang Payment";
                    // set this property if using a token
                    //myCharge.TokenId = *tokenId*;
                    // set these properties if passing full card details
                    // (do not set these properties if you have set a TokenId)

                    myCharge.CardNumber = txtCardNumber.Value;
                    myCharge.CardName = txtCardName.Value;
                    myCharge.CardExpirationYear = drpYear.SelectedItem.Text;
                    myCharge.CardExpirationMonth = drpMonth.SelectedItem.Text;
                    //myCharge.CardAddressCountry = "US";               // optional
                    //myCharge.CardAddressLine1 = "24 Beef Flank St";   // optional
                    //myCharge.CardAddressLine2 = "Apt 24";             // optional
                    //myCharge.CardAddressState = "NC";                 // optional
                    //myCharge.CardAddressZip = "27617";                // optional
                    //myCharge.CardName = "Joe Meatballs";              // optional
                    myCharge.CardCvc = txtCVV.Value;                        // optional

                    // set this property if using a customer
                    //myCharge.CustomerId = *customerId*;

                    // if using a customer, you may also set this property to charge
                    // a card other than the customer's default card
                    //myCharge.Card = *cardId*;

                    // set this if you have your own application fees (you must have your application configured first within Stripe)
                    //myCharge.ApplicationFee = 25;

                    // (not required) set this to false if you don't want to capture the charge yet - requires you call capture later
                    myCharge.Capture = true;

                    var chargeService = new StripeChargeService();
                    StripeCharge stripeCharge = chargeService.Create(myCharge);
                    //    IEnumerable<StripeCharge> response = chargeService.List();
                    if (stripeCharge.Paid == true)
                    {
                        if (Request.QueryString["ordertype"] == "storage")
                        {
                            Update_Order_Id();
                        }
                        else if (Request.QueryString["ordertype"] == "ikea")
                        {
                            Update_IKEA_Order_Id();
                        }
                        //ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Your payment is successfull');", true);                                                              
                    }

                    //MessageBox.Show("");
                    //Response.Redirect("dashboard.aspx");
                }

                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('Please select Terms and Policy');", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('" + ex.Message.ToString() + "');", true);

            }
            
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            if(Request.QueryString["ordertype"] == "storage")
            {
                Response.Redirect("dashboard.aspx");
            }
            else if(Request.QueryString["ordertype"] == "ikea")
            {
                Response.Redirect("ikea-dashboard.aspx");
            }
        }

        private void Update_Order_Id()
        {
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
            {
                Cn.Open();
                string strUpd = "Update order_table set is_payment_confirm=1 where order_id='" + Session["orderid"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand(strUpd, Cn);
                Cmd.ExecuteNonQuery();
                //Session["orderid"] = "";
                Response.Redirect("thanks.aspx");
            }
        }

        private void Update_IKEA_Order_Id()
        {
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            using (MySqlConnection Cn = new MySqlConnection(ConnStr.ToString()))
            {
                Cn.Open();
                string strUpd = "Update ikea_order_table set is_payment_confirm=1 where order_id='" + Session["orderid"].ToString() + "'";
                MySqlCommand Cmd = new MySqlCommand(strUpd, Cn);
                Cmd.ExecuteNonQuery();
                Session["orderid"] = "";
                Response.Redirect("ikea-dashboard.aspx");
            }
        }


        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("index.html");
        }
          
      
    }
